export const metadata = {
  title: 'INUMAP TOKYO — 江戸川区 犬連れ引越しスコアマップ',
  description: '江戸川区の丁目レベルで犬連れ生活のしやすさをスコア化。散歩環境・動物病院・ペット可物件・カフェ・防災リスクを地図上で比較。',
  openGraph: {
    title: 'INUMAP TOKYO',
    description: '犬連れ引越しの丁目選びに。江戸川区80丁目を5軸でスコア化。',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="ja">
      <body style={{margin:0,padding:0,fontFamily:"'Hiragino Sans','Noto Sans JP',sans-serif"}}>
        {children}
      </body>
    </html>
  );
}

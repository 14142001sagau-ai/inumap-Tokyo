# 🐕 INUMAP TOKYO

江戸川区 丁目レベル 犬連れ引越しスコアマップ

## ローカル起動

```bash
npm install
npm run dev
# → http://localhost:3000
```

## Vercelデプロイ手順（5分）

### 1. GitHubにpush

```bash
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/YOUR_NAME/inumap-tokyo.git
git push -u origin main
```

### 2. Vercelと接続

1. https://vercel.com にログイン（GitHubアカウントで）
2. 「Add New Project」→ GitHubリポジトリを選択
3. 設定はそのままで「Deploy」ボタンを押す
4. 1〜2分でデプロイ完了

### 3. カスタムドメイン（任意）

Vercelダッシュボード → Project Settings → Domains
→ `inumap.tokyo` などを追加

## ファイル構成

```
src/
├── app/
│   ├── layout.js      # OGP・メタデータ
│   └── page.js        # エントリーポイント
├── components/
│   └── InuMap.js      # メインコンポーネント（マップ全体）
└── lib/
    └── data.js        # エリアデータ・スコア計算ロジック
```

## Phase2ロードマップ

- [ ] OSM Overpass APIで実データ置き換え（`phase2/collect_data.py`）
- [ ] 23区全体へ拡張
- [ ] ユーザー投稿（犬禁止公園・物件体重制限）
- [ ] 月次バッチ自動更新（GitHub Actions）
